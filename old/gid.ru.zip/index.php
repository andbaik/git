<?php 
$dir    = 'files_ns';
$BaseFails = [];
$failes = scandir($dir);             //Сканируем директорию с файлами
foreach ($failes as $value) {
	if (substr($value,0,2)=='ns'){
		$BaseFails[]=$value;     //Записываем названия файлов в переменную
	}
}

	for ($i=0; $i < count($BaseFails); $i++) { //Вывод на экран список
	 	StrFails(BaseFails[$i]);
	 } 




 function StrFails($BaseFails) 
 {
 	$handle = @fopen("$BaseFails", "r");
if ($handle) {
    $Data = array();
    while (($buffer = fgets($handle, 4096)) !== false) {
        $Data[] = $buffer;
    }
    if (!feof($handle)) {
        echo "Error: unexpected fgets() fail\n";
    }
    fclose($handle);
}

 	return ($Date);
 }

 ?>